package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Testaccount {
	private WebDriver driver;

    public Testaccount(WebDriver driver) {
        this.driver = driver;
    }

    public void getTitleMrsRadio() {
         driver.findElement(By.id("id_gender2")).click();
    }

    public void getPasswordInput() {
         driver.findElement(By.id("password")).sendKeys("Automation@123");
    }

    public void getDayDropdown() {
         driver.findElement(By.id("days"));
    

    WebElement monthElement = driver.findElement(By.className("react-datepicker__month-select"));
	monthElement.click();
	Select monthSelect=new Select(monthElement);
	monthSelect.selectByVisibleText("November");
	
	WebElement yearElement=driver.findElement(By.className("react-datepicker__year-select"));
	yearElement.click();
	Select yearSelect=new Select(yearElement);
	yearSelect.selectByValue("1996");
	driver.findElement(By.cssSelector("div[aria-label*='November 11, 1996']")).click();
    }

    public void getNewsletterCheckbox() {
         driver.findElement(By.id("newsletter")).click();
    }

    public void getOffersCheckbox() {
         driver.findElement(By.id("optin")).click();
    }

    public void getFirstNameInput() {
         driver.findElement(By.id("first_name")).sendKeys("admin");
    }

    public void getLastNameInput() {
         driver.findElement(By.id("last_name")).sendKeys("automation");
    }

    public void getCompanyInput() {
         driver.findElement(By.id("company")).sendKeys("GrowskillIT");
    }

    public void getAddress1Input() {
         driver.findElement(By.id("address1")).sendKeys("Address1");
    }

    public void getAddress2Input() {
         driver.findElement(By.id("address2")).sendKeys("Address2");
    }

    public void getCountryDropdown() {
         driver.findElement(By.id("country")).sendKeys("India");
         ((WebElement) driver).sendKeys(Keys.ENTER);
    }

    public void getStateInput() {
         driver.findElement(By.id("state")).sendKeys("Karnataka");
    }

    public void getCityInput() {
         driver.findElement(By.id("city")).sendKeys("Bangalore");
    }

    public void getZipcodeInput() {
         driver.findElement(By.id("zipcode")).sendKeys("123445");
    }

    public void getMobileNumberInput() {
         driver.findElement(By.id("mobile_number")).sendKeys("9344434324");
    }

    public void getCreateAccountButton() {
         driver.findElement(By.xpath("//button[@data-qa='create-account-button']")).click();
    }

    public boolean isEnterAccountInfoVisible() {
        return driver.findElement(By.xpath("//h2[text()='ENTER ACCOUNT INFORMATION']")).isDisplayed();
    }
}
