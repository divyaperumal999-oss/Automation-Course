package tests;

import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import drivers.DriverManager;
import pages.RegisterPage;
import utilities.ExcelUtil;

public class SignupTest extends BaseTest {
	@Test()
	public void performSignup() 
	{
		RegisterPage registerpage = new RegisterPage(DriverManager.getDriver());
		registerpage.enterUsername("Automation");
		registerpage.enterEmailAddress("Automation123@gmail.com");
		registerpage.clickSignup();
		
		String pageTitle = registerpage.getSignupTitle();
//		System.out.println(pageTitle);
		
		Assert.assertEquals(pageTitle, "Automation Exercise");	
	}
	
	@DataProvider(name = "SignupData")
	public Object[][] getData()
	{
		Object[][] obj = {
				{"manual","Automation123@gmail.com"},
				{"normaluser","NormalUser@gmail.com"}
		};
		return obj;
	}
	
	
	@Test(dataProvider = "SignupData")
	public void PerformSignupWithData(String Username, String emailAddress)
	{
		RegisterPage signupPage = new RegisterPage(DriverManager.getDriver());
		signupPage.enterUsername(Username);
		signupPage.enterEmailAddress(emailAddress);
		signupPage.clickSignup();
		
		String pageTitle = signupPage.getSignupTitle();
		
		Assert.assertEquals(pageTitle, "Automation Exercise");	
	}
	

	
	
	@DataProvider(name = "signupWithExcel")
	public Object[][] getDataExcel()
	{
	List<Map<String, String>> data = ExcelUtil.getData("src/test/resources/testdata/TestData.xlsx","Sheet1");
		
		Object[][] result = new Object[data.size()][1];
		
		for(int i = 0;i<data.size();i++)
	{
			result[i][0] =  data.get(i);
		}
		return result;		
	}
	
	
	@Test(dataProvider = "signupWithExcel")
	public void testSignupWithExcel(Map<String, String> testData)
	{		
		
		RegisterPage SignupPage = new RegisterPage(DriverManager.getDriver());
		SignupPage.enterUsername(testData.get("admin"));
		SignupPage.enterEmailAddress(testData.get("emailAddress"));
		SignupPage.clickSignup();
		
		String pageTitle = SignupPage.getSignupTitle();
		
		Assert.assertEquals(pageTitle, "Automation Exercise");	
		
		
	}

}
