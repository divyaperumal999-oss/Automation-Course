package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage extends BasePage{
	public RegisterPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@data-qa='signup-email']") 
	WebElement userNameText;
	
	@FindBy(xpath = "//input[@data-qa='signup-email']")
	WebElement emailAddress;
	
	@FindBy(xpath = "//button[@data-qa='signup-button']")
	WebElement signupButton;
	
	
	
	public void enterUsername(String userName)
	{
//		driver.findElement(userNameText).sendKeys(userName);
		
//		userNameText.sendKeys(userName);
		
		type(userNameText,userName);
	}
	
	public void enterEmailAddress (String email)
	{
//		driver.findElement(emailAddress).sendKeys(email);
		
//		emailAddress.sendKeys(email);
		
		type(emailAddress,email);
	}
	
	
	public void clickSignup()
	{
//		driver.findElement(signupButton).click();
		
		click(signupButton);
	}
	
	
	public String getSignupTitle()
	{
		return driver.getTitle();
	}

}
