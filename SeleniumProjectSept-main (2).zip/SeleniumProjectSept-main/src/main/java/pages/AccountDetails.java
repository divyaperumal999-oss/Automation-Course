package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AccountDetails {
	private WebDriver driver;

    public AccountDetails(WebDriver driver) {
        this.driver = driver;
    }

    public void getContinueButton() {
         driver.findElement(By.xpath("//a[@data-qa='continue-button']"));
    }

    public boolean isAccountCreatedVisible() {
        return driver.findElement(By.xpath("//h2[text()='ACCOUNT CREATED!']")).isDisplayed();
    }
}

