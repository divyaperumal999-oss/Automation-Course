package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterUser extends BasePage
{


	public RegisterUser(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@data-qa='signup-name']") 
	WebElement userNameText;
	
	@FindBy(xpath = "//input[@data-qa='signup-email']")
	WebElement emailText;
	
	@FindBy(xpath = "//button[@data-qa='signup-button']")
	WebElement signupButton;
	
	
	
	public void enterUsername(String userName)
	{

		
		type(userNameText,userName);
	}
	
	public void enteremail(String email)
	{
		
		type(emailText,email);
	}
	
	
	public void clicksignup()
	{

		
		click(signupButton);
	}
	
	
	public String getSignUPTitle()
	{
		return driver.getTitle();
	}

}

